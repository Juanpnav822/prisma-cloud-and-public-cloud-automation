
# Asset Explorer Filtered by Custom Compliance Standards

This script was made as an "out of the box" effort to provide the compliance status data for a PowerBi Dashboard made by Sura Security Team. This dashboard will show all the assets, failing and passing against compliance controls from specific compliance standards based on CIS benchmarks for AWS, Azure & OCI.

## Prerequisites

1. Prisma Cloud Access Key with Admin permissions.
2. Python 3.11 installed.
3. NodeJS installed.
4. Access to Azure with deploy resources permission.
5. Terraform installed.

## What and how it does

This script export to a Storage Account in Azure the state compliance for each main cloud (AWS, Azure and OCI) filtered by three environments, Production, Development and Lab. The output consist of 3 files, each one for each Cloud provider.

You can find these compliance names in the variable (list) named 'compliances'.

Limitations: Prisma Cloud CSPM API endpoint to get the assets, doesn't bring some assets like _account/subscriptions/compartments,_ so some compliance sections, even if they have assets breaking the rule, won't appear in the report made by this script.

A brief look to the architecture is:

![Solution's Architecture](./images/Azure_PrismaReports_PowerBI_Diagraman.jpg)

## Usage

1. Clone or download this project to your local machine.
  ```
  git clone https://github.com/bsantacruz-netdata/Cloud-Native-Netdata.git
  ```

2. Open your terminal into cloned repo or upload the *.tf files to Azure Cloudshell.

3. Create the needed infrastructure on Azure with Terraform executing following commands in *.tf files location.
  ```
  az login
  terraform init
  terraform fmt
  terraform validate
  terraform apply --auto-approve
  ```

*Disclaimer:* There are two ways to execute this script.

### Execute it on your local machine

1. Install the libraries listed in requirement.txt file
  
  ```
   pip install -r /$path_to/requirements.txt
  ```
  
2. Set the global variables needed by the script:
  ```
  export ACCESS_KEY="YourPrismaAPIAccessKey"
  export SECRET="YourPrismaAPISecretKey"
  export CONNECTION_STRING="YourAzureStorageConnectionString"
  ```

3...

### Execute it on Azure Functions

1. Open the function created with terraform named 'fn-prismacloudreports' an select 'Create function'  > 'Any Editor'.

2. Select configuration & change the values of the environment variables for the function.

  ```
  ACCESS_KEY="YourPrismaAPIAccessKey"
  SECRET="YourPrismaAPISecretKey"
  CONNECTION_STRING="YourAzureStorageConnectionString"
  ```

3. Create a folder on your local machine to connect it to the Azure Function, locate your terminal on that folder.

4. Runs following commands to create publish function to Azure.

  ```
  npm install -g  azure-functions-core-tools@4 --unsafe-perm true
  func init
  func new
  ```

5. Copy the files `function_app.py`, `requirements.txt` & `host.json` into the recent created folder, replacing the new created ones. Then run this command to deploy the function app in Azure:
  ```
  az login
  func azure functionapp publish [Your-Azure-Function-Name]
  ```

6. The function is a timer trigger that runs at 9 AM UTC. If you want to change the schedule, change the parameter 'schedule' on line 384, 312 and/or 240.

### Others Considerations

You can optionally use other methods to deploy this function app, please refer to microsoft documentation for these methods. https://learn.microsoft.com/en-us/azure/azure-functions/

Finally, you can customize this script to make reports of different compliance standards by changing the variable list 'compliances' along with the associated variables 'accountGroup', 'ambiente' and 'cloud'.


*Created by:* Juan Pablo Navarrete @Juanpnav822 & Breider A. Santacruz @bsantacruz-netdata
*Client:* SURA Group
