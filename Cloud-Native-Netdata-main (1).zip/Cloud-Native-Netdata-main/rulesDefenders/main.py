import requests, json, os
from dotenv import load_dotenv
load_dotenv()

PRISMA_ACCESS_KEY_ID = os.environ['PRISMA_ACCESS_KEY_ID']
PRIMAS_SECRET_ACCESS_KEY = os.environ['PRIMAS_SECRET_ACCESS_KEY']
TENANT = os.environ['TENANT']
CWPP = os.environ['CWPP']
token = ""


def loginCSPM():
    global token
    url = f"https://{TENANT}/login"
    payload = {
        "password": PRIMAS_SECRET_ACCESS_KEY,
        "username": PRISMA_ACCESS_KEY_ID,
    }
    headers = {"content-type": "application/json; charset=UTF-8"}
    response = requests.request("POST", url, json=payload, headers=headers)
    if response.status_code == 200:
        token = (json.loads(response.text))["token"]
        # return (json.loads(response.text))["token"]
    else: 
        raise ValueError(response.text)
    


def loginCWPP():
    global token
    url = f"https://{CWPP}/api/v22.06/authenticate"
    payload = {
        "password": PRIMAS_SECRET_ACCESS_KEY,
        "username": PRISMA_ACCESS_KEY_ID,
    }
    headers = {"content-type": "application/json; charset=UTF-8"}
    response = requests.request("POST", url, json=payload, headers=headers)
    if response.status_code == 200:
        token = (json.loads(response.text))["token"]
        # return (json.loads(response.text))["token"]
    else: 
        raise ValueError(response.text)
    

def listCredentials():
    url = f"https://{CWPP}/api/v22.06/credentials?project=Central+Console"
    headers = {
        "content-type": "application/json; charset=UTF-8",
        "x-redlock-auth": token
    }
    response = requests.request("GET", url, headers=headers)
    if response.status_code == 200:
        return (json.loads(response.text))
    else: 
        raise ValueError(response.text)
    

def listRulesAutoDefenders():
    url = f"https://{CWPP}/api/v1/settings/serverless-auto-deploy?project=Central+Console"
    headers = {
        "content-type": "application/json; charset=UTF-8",
        "x-redlock-auth": token
    }
    response = requests.request("GET", url, headers=headers)
    print(response)
    if response.status_code == 200:
        return (json.loads(response.text))
    else: 
        raise ValueError(response.text)
    

def createRuleAutoDefender(rules):
    url = f"https://{CWPP}/api/v1/settings/serverless-auto-deploy?project=Central+Console"
    headers = {
        "content-type": "application/json; charset=UTF-8",
        "x-redlock-auth": token
    }

    payload = rules
    response = requests.request("POST", url, json=payload, headers=headers)
    print(response)
    if response.status_code == 200:
        return (response.text)
    else: 
        raise ValueError(response.text)


def generateRules():
    credentials = listCredentials()
    currentList = listRulesAutoDefenders()
    print(currentList[0])
    rules = []
    for credential in credentials:
        # print(credential)
        name = f'{credential["accountName"]}-{credential["accountID"]}'
        credentialID = credential["_id"]
        accountID = credential["accountID"]
        exist = searchElementInList(currentList, credential["_id"])
        typeCloud = credential["type"]
        if (not exist) and ("DEV" in credential["accountName"] or "QA" in credential["accountName"]) and len(name) != 0 and len(accountID) != 0 and len(credentialID) != 0 and typeCloud == "aws":
            # print(next(item for item in currentList if item["credentialID"] == credential["_id"]), None)
            print(searchElementInList(currentList, credential["_id"]))
            # print(credential["accountName"], credentialID, accountID)
            # print("DEV" in credential["accountName"] or "QA" in credential["accountName"])
            # print(name, credentialID, accountID)
            rule = {
                "consoleAddr": "us-east1.cloud.twistlock.com",
                "runtimes": [
                    "nodejs12.x",
                    "nodejs14.x",
                    "python3.6",
                    "python3.8",
                    "python3.7",
                    "python3.9",
                    "ruby2.7"
                ],
                "awsRegionType": "regular",
                "collections": [
                    {
                        "hosts": [
                            "*"
                        ],
                        "images": [
                            "*"
                        ],
                        "labels": [
                            "*"
                        ],
                        "containers": [
                            "*"
                        ],
                        "functions": [
                            "*"
                        ],
                        "namespaces": [
                            "*"
                        ],
                        "appIDs": [
                            "*"
                        ],
                        "accountIDs": [
                            "*"
                        ],
                        "codeRepos": [
                            "*"
                        ],
                        "clusters": [
                            "*"
                        ],
                        "name": "All",
                        "owner": "system",
                        "modified": "2021-01-31T08:32:41.974Z",
                        "color": "#3FA2F7",
                        "description": "System - all resources collection",
                        "system": True,
                        "prisma": False
                    }
                ],
                "credentialID": credentialID,
                "name": name,
                "proxy": {
                    "httpProxy": "",
                    "ca": "",
                    "user": "",
                    "noProxy": "",
                    "password": {
                        "encrypted": "",
                        "plain": ""
                    }
                }
            }
            rules.append(rule)
        # break
    print(rules)
    return currentList + rules

def searchElementInList(list, element):
    for item in list:
        if 'credentialID' in item and item['credentialID'] == element:
            return True
    return False



def main():
    # loginCWPP()
    loginCSPM()
    # listCredentials()
    rules = generateRules()
    # print(currentList + rules)
    createRuleAutoDefender(rules)


main()
