import boto3, csv, datetime, json, os, requests, time
import pandas as pd
from botocore.exceptions import ClientError
from csv import QUOTE_ALL
from datetime import date
from datetime import timedelta
from dotenv import load_dotenv

# ## Take environment variables from .env
load_dotenv()

inventory = 'v2/inventory'
cspm_url_login = os.environ['CSPM_URL_LOGIN']
cspm_url_report = os.environ['CSPM_URL_REPORT']
access_key_id = os.environ['ACCESS_KEY_ID']
secret_access_key = os.environ['SECRET_ACCESS_KEY']


# complianceStats = 'stats/compliance/download'
# hosts = 'hosts/download'
# registry = 'registry/download'
# images = 'images/download'
# container = 'containers/download'
# defenders = 'defenders/download'
# radar_cluster = 'radar/container/clusters'
# radar_container = 'radar/container'
# radar_ns = 'radar/container/namespaces'
# radar_host = 'radar/host'
tenant = os.environ['TENANT']
Region = os.environ['REGION']
bucketName = os.environ['BUCKET_NAME']
secret_name = os.environ['SECRET_NAME']
s3 = boto3.resource('s3')
bucket = s3.Bucket(bucketName)
today = date.today()
key = "PRISMA"

#
audits_incidents = "audits/incidents/download"
now = datetime.datetime.utcnow()
delta = now - timedelta(days=7)
#

def getToken(accesskey,secret):

	print('Autenticando...')
	# loginurl = "https://{}/api/v1/authenticate".format(tenant)		<-		Eliminar si todo funciona
	loginurl = cspm_url_login.format(tenant)
	
	credentials = {"username": accesskey,"password": secret}
	payload = json.dumps(credentials)
	headers = {
	    "Accept": "application/json; charset=UTF-8",
    	"Content-Type": "application/json; charset=UTF-8"
	}
	loginresp = requests.request("POST", loginurl, data=payload, headers=headers)
	if loginresp.status_code == 200:
		loginresp = json.loads(loginresp.content)
		token = loginresp['token']
		print('Autenticado exitoso!')
	else:
		print('\nValidar credenciales y/o tenant...\n')
	return token

def get_secret():
	
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=Region,
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            print("The requested secret " + secret_name + " was not found")
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            print("The request was invalid due to:", e)
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            print("The request had invalid params:", e)
    else:
        if 'SecretString' in get_secret_value_response:
            text_secret_data = json.loads(get_secret_value_response['SecretString'])
            return text_secret_data
        else:
            binary_secret_data = get_secret_value_response['SecretBinary']

def upload_file(file, bucket, object_name, r):
	object_name = os.path.relpath(object_name, '/tmp')
	object_name = key + "/" + r + "/" + object_name
	upload = bucket.upload_file(file, object_name)
	os.remove(file)

def InsertColumn(filename):
	
	d1 = today.strftime("%d/%m/%Y")
	df = pd.read_csv(filename)
	df.insert(0,'ReportDate','')
	df["ReportDate"] = d1
	df.to_csv(filename, index=False, quoting=csv.QUOTE_ALL)

def GetReport(token,r,path):

	print('Generando ' + r + '...')
	# url = "https://{}/api/v1/{}".format(tenant,path)		<-		Eliminar si todo funciona
	url = cspm_url_report.format(tenant,path)
	# token = 'Bearer ' + token
	# headers = {
    # 	'Authorization': token,
	# }
	headers = {
    	'x-redlock-auth': token,
	}

	fecha = time.localtime()
	## Quitar los comentario para permitir la subida de los csv al bucket *************************************
	# filename = '/tmp/{}_{}_{}_{}_{}_{}.csv'.format(r,fecha.tm_year,fecha.tm_mon,fecha.tm_mday,fecha.tm_hour,fecha.tm_min)
	filename = 'C:/Users/gerardo.torres/Documents/Developments/CSPM/download/{}_{}_{}_{}_{}_{}.csv'.format(r,fecha.tm_year,fecha.tm_mon,fecha.tm_mday,fecha.tm_hour,fecha.tm_min)
	# querystring = {"from":delta.isoformat() + 'Z',"to":now.isoformat() + 'Z'}
	querystring = {
			'timeType':'relative',
			'timeAmount':30,
			'timeUnit':'day',
			'cloud.service':'Amazon ECS'
		}
	# if audits_incidents == "audits/incidents/download":
	# 	req = requests.get(url, headers=headers,params=querystring)
	# else:
	# 	req = requests.get(url, headers=headers)
	print("Response ***********************************************************")
	print('URL:     ', url)
	print('HEADERS: ', headers)
	print('PARAMS:  ', querystring)
	print("********************************************************************")
	req = requests.get(url, headers=headers,params=querystring)
	print("Response ***********************************************************")
	print(req.content)
	print("********************************************************************")

	url_content = req.content
	csv_file = open('%s' % filename, 'wb')
	csv_file.write(url_content)
	csv_file.close()
	print(r + ' generado!')
	time.sleep(1)
	csv_file = InsertColumn(filename)
	print(r + ' modificado con la columna Date!')
	## Quitar los comentario para permitir la subida de los csv al bucket *************************************
	# print('Cargando ' + r + ' en ' + bucketName)
	# upload = upload_file(filename, bucket, filename, r)
	# print(r + ' cargado en ' + bucketName + "!!!")

def GetReportJson(token,r,path,cl):
	
	csvf = "csv"
	jsonf = "json"
	print('Generando ' + r + '...')
	url = "https://{}/api/v1/{}".format(tenant,path)
	token = 'Bearer ' + token
	headers = {
    'Authorization': token,
	}
	fecha = time.localtime()
	json_fn = '/tmp/{}_{}_{}_{}_{}_{}.{}'.format(r,fecha.tm_year,fecha.tm_mon,fecha.tm_mday,fecha.tm_hour,fecha.tm_min,jsonf)
	csv_fn = '/tmp/{}_{}_{}_{}_{}_{}.{}'.format(r,fecha.tm_year,fecha.tm_mon,fecha.tm_mday,fecha.tm_hour,fecha.tm_min,csvf)
	if r == 'namespaces_count':
		ns_dict = {}
		new_dict = {}
		for i in cl:
			querystring = {"cluster":i}
			req = json.loads(requests.get(url, headers=headers, params=querystring).content)
			ns_dict[i] = req
		req = ns_dict
	elif r == 'container_count':
		ns_dict = {}
		new_dict = {}
		for i in cl:
			querystring = {"clusters":i}
			req1 = requests.get(url, headers=headers, params=querystring)
			req2 = json.loads(req1.content)
			ns_dict[i] = {}
			ns_dict[i]['containerCount'] = req2['containerCount']
		req = ns_dict
	else:
		ns_dict = {}
		querystring = {}
		datetime = today.strftime("%d/%m/%Y")
		resp = requests.get(url, headers=headers, params=querystring).content
		resp = json.loads(resp)
		req = resp
	req1 = json.dumps(req, indent=4, sort_keys=True)
	json_file = open('%s' % json_fn, 'w')
	json_file.write(req1)
	json_file.close()
	print(r + ' generado!')
	time.sleep(1)
#	if r == '':
#		print('Cargando el json de ' + r + ' en ' + bucketName)
#		upload = upload_file(json_fn, bucket, json_fn, r)
#		print(r + ' cargado en ' + bucketName + "!!!")
	if r == 'namespaces_count':
		with open(csv_fn, mode='w') as ns_file:
			create = csv.writer(ns_file, delimiter=',')
			create.writerow(['ClusterName', 'Namespaces'])
			for k,v in req.items():
				for value in v:
					with open(csv_fn, 'a+', newline='') as ns_file:
						fn = ['ClusterName', 'Namespace']
						add_ns = csv.writer(ns_file, delimiter=',')
						add_ns.writerow([k, value])
	elif r == 'container_count':
		df = pd.DataFrame.from_dict(req, orient='index')
		df.to_csv (csv_fn)
	else:
		df = pd.read_json(json_fn)
		df.to_csv (csv_fn, index = None)
	csv_file = InsertColumn(csv_fn)
	print(r + ' modificado con la columna Date!')
	print('Cargando el csv de ' + r + ' en ' + bucketName)
	upload = upload_file(csv_fn, bucket, csv_fn, r)
	print(r + ' cargado en ' + bucketName + "!!!")
	return req

# def lambda_handler(event, context):
def lambda_handler():

	## Quitar los comentario para permitir obtener los secrets *************************************
	# secret = get_secret()
	# for key, value in secret.items():
	# 	user = key
	# 	password = value
	## Eliminar access_key_id y secret_access_key *************************************
	user = access_key_id
	password = secret_access_key
	token = getToken(user,password)
	v2_inventory = GetReport(token, r='v2_inventory',path=inventory)
	# hosts_report = GetReport(token, r='host_report',path=hosts)
	# container_report = GetReport(token, r='container_report',path=container)
	# images_report = GetReport(token, r='images_report',path=images)
	# registry_report = GetReport(token, r='registry_report',path=registry)
	# defender_report = GetReport(token, r='defender_report',path=defenders)
	# compliance_stats = GetReport(token, r='compliance_stats',path=complianceStats)
	# # audits_incidents_report = GetReport(token, r='incidents_report',path=audits_incidents)
	# radar_cluster_report = GetReportJson(token, r='clusters',path=radar_cluster,cl='')
	# res  = []
	# for i in radar_cluster_report:
	# 	res.append(i['name'])
	# cluster_list = list(filter(None, res))
	# namespaces_report = GetReportJson(token,r='namespaces_count',path=radar_ns, cl=cluster_list)
	# radar_container_report = GetReportJson(token,r='container_count',path=radar_container, cl=cluster_list)
	print('Se finalizo todo el proceso exitosamente!!!')

def _ini_():
	lambda_handler()

_ini_()