import csv, datetime, json, os, requests, time
import pandas as pd
from csv import QUOTE_ALL
from datetime import date
from datetime import timedelta
from dotenv import load_dotenv
import csv
# ## Take environment variables from .env
load_dotenv()

inventory = 'v2/inventory'
cspm_url_login = os.environ['CSPM_URL_LOGIN']
cspm_url_report = os.environ['CSPM_URL_REPORT']
access_key_id = os.environ['ACCESS_KEY_ID']
secret_access_key = os.environ['SECRET_ACCESS_KEY']

key = os.environ['PREFIX']
tenant = os.environ['TENANT']
folder = os.environ['FOLDER']


def getToken(accesskey,secret):

	print('Autenticando...')
	# loginurl = "https://{}/api/v1/authenticate".format(tenant)		<-		Eliminar si todo funciona
	loginurl = cspm_url_login.format(tenant)
	
	credentials = {"username": accesskey,"password": secret}
	payload = json.dumps(credentials)
	headers = {
	    "Accept": "application/json; charset=UTF-8",
    	"Content-Type": "application/json; charset=UTF-8"
	}
	loginresp = requests.request("POST", loginurl, data=payload, headers=headers)
	if loginresp.status_code == 200:
		loginresp = json.loads(loginresp.content)
		token = loginresp['token']
		print('Autenticado exitoso!')
	else:
		print('\nValidar credenciales y/o tenant...\n')
	return token

# Funtion for get list of inventory that return list of services of a tenant
def listInventory(the_token):
	url = f"https://{tenant}/v2/inventory"
	# Se definen el encabezado de la peticion, en donde es necesario enviar el token
	headers = {
		"content-type": "application/json",
		'x-redlock-auth': the_token,
	}
	querystring = {
		'timeType':'relative',
		'timeAmount':30,
		'timeUnit':'day',
	}
	# Se define el body de la petición, en donde se especifica el filtro del tipo de cloud que se necesita, para este caso AWS
	# Se especifica el tipo de elemento por el cual va agrupar, en este caso se necesitan las lista de servicios.
	payload = {	
		"groupBy": ["cloud.service"],
		"filters": [
			{
				"name": "cloud.type",
				"operator": "=",
				"value": "aws"
			}
		],
	}
	# Se realiza una petición POST al endpoint con los parámetros establecidos.
	response = requests.request("POST", url, headers=headers, json=payload, params=querystring)
	# Se obtiene el resultado de la petición y se accede al objeto groupedAggregates que contiene un array con la lista de serivicios
	items = json.loads(response.content)["groupedAggregates"]
	print(f"Number services: {len(items)}")
	return items

# Funtion for get list of resource of a inventory that return list of resources of a service
def listSources(the_token, serviceName):
	url = f"https://{tenant}/v2/inventory"
	# Se definen el encabezado de la peticion, en donde es necesario enviar el token
	headers = {
		"content-type": "application/json",
		'x-redlock-auth': the_token,
	}
	querystring = {
		'timeType':'relative',
		'timeAmount':30,
		'timeUnit':'day',
	}
	# Se define el body de la petición, en donde se especifica el filtro del tipo de cloud que se necesita, para este caso AWS
	# Se especifica el tipo de elemento por el cual va agrupar, en este caso se necesitan las lista de resources para un servicio especificado.
	payload = {	
		"groupBy": ["resource.type"],
		"filters": [
			{"name": "groupBy", "operator": "=", "value": "resource.type"},
			{"name": "cloud.service", "operator": "=", "value": serviceName},
			{"name": "cloud.type", "operator": "=", "value": "aws"}
		]
	}
	response = requests.request("POST", url, headers=headers, json=payload, params=querystring)
	sources = json.loads(response.content)["groupedAggregates"]
	# print(f"Number sources: {len(sources)}")
	return sources

# Funtion for get list of asset of a resource that return list of assets of a resource
def listAssets(the_token, service, resource):
	assets = []
	url = f"https://{tenant}/resource/scan_info"
	headers = {
		"content-type": "application/json",
		'x-redlock-auth': the_token,
	}
	querystring = {
		'timeType':'relative',
		'timeAmount':30,
		'timeUnit':'day',
	}
	payload = {	
		"limit": 300,
		"filters": [
			{"name": "includeEventForeignEntities", "operator": "=", "value": "false"},
			{"name": "cloud.service", "operator": "=", "value": service},
			{"name": "cloud.type", "operator": "=", "value": "aws"},
			{"name": "resource.type", "operator": "=", "value": resource},
			{"name": "scan.status", "operator": "=", "value": "all"},
			{"name": "decorateWithDerivedRRN", "operator": "=", "value": "false"}
		]
	}
	while True:
		response = requests.request("POST", url, headers=headers, json=payload, params=querystring)
		content = json.loads(response.content)
		assets = assets + content["resources"]
		if "nextPageToken" in content:
			payload["pageToken"] = content["nextPageToken"]
		else:
			break
	# print(len(assets))
	return assets

# Funtion for generate assets report
def generateReport(the_token):
	print("Generando reporte!")
	assets_csv = []
	# List of inventory
	items = listInventory(the_token)
	number_service = 0
	number_source = 0
	# Iterate item in inventory
	for item in items:
		number_service = number_service + 1
		print(f"number_service: {number_service}/{len(items)}")
		totalResources = item["totalResources"]
		serviceName = item["serviceName"]
		# Obtener la lista de resources para cada servicios
		sources = listSources(the_token, serviceName)
		# Iterate sources for get assets list
		for resource in sources:
			number_source = number_source + 1
			# print(f"number_source: {number_source}")
			resourceTypeName = resource["resourceTypeName"]
			# Obtener la lista de assets para cada resource
			assets = listAssets(the_token, serviceName, resourceTypeName)
			# print(len(assets))
			# Iterate assets
			for asset in assets:
				# Se crea el elemento para cada asset teniendo en cuenta los campos solicitados
				element = {
					"ServiceName": serviceName,
					"Total": totalResources,
					"AssetID": asset["id"],
					"AssetName": asset["name"],
					"AccountID": asset["accountId"],
					"AccountName": asset["accountName"],
					"RegionID": asset["regionId"],
					"Region": asset["regionName"]
				}
				assets_csv.append(element)
				# break
			# break
		# break
	print(f"Número total de assets: {len(assets_csv)}")
	keys = assets_csv[0].keys()
	dt = datetime.datetime.now()
	ts = datetime.datetime.timestamp(dt)
	with open(f'{folder}/general_inventory_{int(ts)}.csv', 'w', newline='') as output_file:
		dict_writer = csv.DictWriter(output_file, keys)
		dict_writer.writeheader()
		dict_writer.writerows(assets_csv)

def lambda_handler():
	user = access_key_id
	password = secret_access_key
	token = getToken(user,password)
	generateReport(token)
	print('Se finalizo todo el proceso exitosamente!!!')

def _ini_():
	lambda_handler()

_ini_()