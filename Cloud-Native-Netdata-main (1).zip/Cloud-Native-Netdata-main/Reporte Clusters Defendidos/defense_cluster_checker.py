# This script fetches data from the Prisma Cloud cloud discovery and defenders APIs,
# extracts unique clusters, compares clusters, and generates an Excel report that summarizes the findings.
# The report includes the number of defended and non-defended clusters,
# as well as a pie chart depicting the distribution of defended and non-defended clusters.

import requests
import csv
import json
import pandas as pd
import matplotlib.pyplot as plt
from openpyxl import load_workbook
import xlsxwriter
import datetime


# Get the current date and time
now = datetime.datetime.now()
formatted_date = now.strftime("%d-%m_%H-%M")

# Define your variables
user = ""
AccessKeyID = ""
SecretKeyID = ""
console = ""
version = "v1"
file_name = f"cluster_comparison_{formatted_date}.xlsx"
# Define the API URLs
api_url_cloud = f"{console}/api/{version}/cloud/discovery/download?serviceType=aws-eks"
api_url_defenders = f"{console}/api/{version}/defenders/download?project=Central+Console&connected=true&type=daemonset,cri"

def getToken(AccessKeyID, SecretKeyID):

	print("\nAutenticando las credenciales...")
	url = "{}/api/{}/authenticate".format(console, version)
	credentials = {"username": AccessKeyID,"password": SecretKeyID}
	payload = json.dumps(credentials)
	headers = {
		"Accept": "application/json",
	 	"Content-Type": "application/json"
	}
	api_call = requests.request("POST", url, data=payload, headers=headers)
	if api_call.status_code == 200:
		api_call = json.loads(api_call.text)
		token = api_call["token"]
		print("¡Autenticado exitosamente!\n")
	else:
		print("Validar credenciales y/o tenant\n")
	return token


# Function to perform GET request and return CSV data
def getCSV(token, url, report):

    url = url
    print(url)
    token = "Bearer " + token
    headers = {
    "Authorization": token,
    "Accept": "application/json"
    }
    api_call = requests.request("GET", url, headers=headers)
    status = api_call.status_code

    if status == 200:
        print("La llamada a la API ha tenido éxito.")
        print(f"Generando el reporte: {report}")	
        request = api_call.content
        csv_file = open(f"{report}.csv", "wb")
        csv_file.write(request)
        csv_file.close()
        print(f"El reporte {report} ha sido generado exitosamente\n")
        with open(f"{report}.csv", mode='r') as file:
            csv_reader = csv.reader(file)
            data = list(csv_reader)
        return data
    else:
        print("La llamada a la API ha fallado con el código de estado:", status)
        return None


# Function to extract unique clusters from CSV data
def extract_clusters(csv_data, column_index):
    return {row[column_index] for row in csv_data[1:]}


# Get data from both APIs
token = getToken(AccessKeyID,SecretKeyID)
cloud_csv_data = getCSV(token, api_url_cloud, report="cloud_"+formatted_date)
defenders_csv_data = getCSV(token, api_url_defenders, report="defenders_"+formatted_date)

if cloud_csv_data and defenders_csv_data:
    # Extract clusters
    cloud_clusters = extract_clusters(cloud_csv_data, 8)  # Adjust column index as needed
    # Extract clusters and defended status from cloud discovery
    cloud_clusters_with_defense = [(row[8], row[12].lower() == 'true') for row in cloud_csv_data[1:]]
    cloud_clusters_without_defense = [(row[8], row[12].lower() == 'false') for row in cloud_csv_data[1:]]
    # Separate the clusters and their defended status
    defended_cloud_clusters = [cluster for cluster, is_defended in cloud_clusters_with_defense if is_defended]
    not_defended_cloud_clusters = [cluster for cluster, not_defended in cloud_clusters_without_defense if not_defended]

    defenders_clusters = extract_clusters(defenders_csv_data, 4)  # Adjust column index as needed

    # Count occurrences of each cluster including duplicates
    cluster_counts = pd.Series([row[4] for row in defenders_csv_data[1:]]).value_counts().reset_index()
    cluster_counts.columns = ['Clusters with Nodes', 'Nodes per Cluster']

    # Calculate the total sum of frequencies before extracting unique clusters
    total_sum = cluster_counts['Nodes per Cluster'].sum()

    # Compare clusters
    unique_to_cloud = cloud_clusters - defenders_clusters
    unique_to_defenders = defenders_clusters - cloud_clusters
    combined_defended_clusters = set(defended_cloud_clusters).union(unique_to_defenders)

    df_unique_defenders = pd.DataFrame({'Defended not on AWS': list(unique_to_defenders)})
    df_defended_clusters = pd.DataFrame({'Defended Clusters': list(combined_defended_clusters)})
    df_not_defended_clusters = pd.DataFrame({'Not Defended Clusters': list(not_defended_cloud_clusters)})

    # Count of defended and not defended clusters
    count_defended = len(defended_cloud_clusters)
    count_not_defended = len(not_defended_cloud_clusters)
    
    # Convert total_sum to a DataFrame
    df_total_sum = pd.DataFrame({'Total': [total_sum]})

    # Concatenate the DataFrames horizontally
    df = pd.concat([df_unique_defenders, df_defended_clusters, df_not_defended_clusters, cluster_counts, df_total_sum], axis=1)

    # Replace NaN with empty strings if desired
    df.fillna('', inplace=True)

    # Write the DataFrame to an Excel file
    df.to_excel(file_name, index=False)

    writer = pd.ExcelWriter(file_name, engine='xlsxwriter')
    workbook = writer.book

    # Write data to Excel file
    df.to_excel(writer, sheet_name='Sheet1', startrow=0, header=True, index=False)

    # Create a chart object for defended vs. not defended clusters
    pie_chart1 = workbook.add_chart({'type': 'pie'})

    # Data for the chart
    chart_data = {
        'categories': ['Defended Clusters', 'Not Defended Clusters'],
        'values': [count_defended, count_not_defended]
    }
    df_chart_data = pd.DataFrame(chart_data)
    df_chart_data.to_excel(writer, sheet_name='Sheet1', startrow=150, index=False)

    # Configure the second chart
    pie_chart1.add_series({
        'name': 'Defended vs. Not Defended Clusters',
        'categories': f'=Sheet1!$A${152}:$A${153}',
        'values': f'=Sheet1!$B${152}:$B${153}',
        'data_labels': {'percentage': True},  # Show percentage labels
    })

    # Insert the charts into the worksheet
    worksheet = writer.sheets['Sheet1']
    worksheet.insert_chart('G2', pie_chart1)

    # Close the Pandas Excel writer and output the Excel file
    writer.close()

    # Adjust column width to fit content
    wb = load_workbook(file_name)
    ws = wb.active
    for col in ws.columns:
        max_length = 0
        column = col[0].column_letter  # Get the column name
        for cell in col:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(cell.value)
            except:
                pass
        adjusted_width = (max_length + 2)
        ws.column_dimensions[column].width = adjusted_width

    wb.save(file_name)

    print(f"Excel report generated: {file_name}")
