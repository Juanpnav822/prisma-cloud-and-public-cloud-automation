import requests
import logging


class HTTPRequest:
    def __init__(self, base_url, authentication=None, timeout=10) -> None:
        """
        Initializes an instance of the HTTPRequest class.

        Args:
            base_url (str): The base URL to which requests will be sent.
            authentication (object, optional): An authentication object if authentication is required. Default is None.
            timeout (int, optional): The maximum number of seconds to wait for the request to complete.  Default is
            10 seconds.
        """
        self.base_url = base_url
        self.authentication = authentication
        self.timeout = timeout
        self.session = requests.Session()
        self.logger = logging.getLogger('HTTPRequest')

    def _prepare_headers(self, custom_headers=None):
        headers = {"content-type": "application/json; charset=UTF-8"}
        if self.authentication:
            headers.update(self.authentication)
        if custom_headers:
            headers.update(custom_headers)
        return headers

    def request(self, method, endpoint, payload=None, params=None, custom_headers=None, retries=3) -> dict or str:
        """
        Sends an HTTP request.

        Args:
            method (str): The HTTP method (GET, POST, PUT, DELETE, etc.).
            endpoint (str): The endpoint to which the request will be sent.
            payload (dict, optional): The data to send in the request body, used in POST and PUT requests.  Default
            is None.
            params (dict, optional): The URL parameters to send with the request. Default is None.
            custom_headers (dict, optional): Additional headers for the request. Default is None.
            retries (int, optional): Number of retries in case of transient failures. Default is 3.

        Returns:
            dict or str: The response of the request. If the response is JSON, a dictionary is returned; otherwise,
            a string is returned.
        """
        url = f"{self.base_url}/{endpoint}"
        headers = self._prepare_headers(custom_headers)

        try:
            response = self.session.request(method, url, json=payload, params=params, headers=headers,
                                            timeout=self.timeout)
            response.raise_for_status()

            if response.headers["content-type"] == "application/json":
                return response.json()
            else:
                return response.text

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error in {method} request to {url}: {e}")
            if retries > 0:
                self.logger.warning(f"Retrying {retries} more times...")
                return self.request(method, endpoint, payload, params, custom_headers, retries=retries - 1)
            else:
                raise
