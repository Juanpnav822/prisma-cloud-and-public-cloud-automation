import jwt
from datetime import datetime


def is_jwt_expired(token) -> bool:
    """
    Checks if a JWT token is expired.
    """
    try:
        decoded_token = jwt.decode(token, algorithms=["HS256"], options={"verify_signature": False})
        expiration_time = decoded_token.get('exp')
        current_time = datetime.now().timestamp()
        if expiration_time and current_time <= expiration_time:
            return False  # Token is not expired
        else:
            return True  # Token has expired
    except jwt.ExpiredSignatureError:
        return True  # Token has expired
    except jwt.InvalidTokenError:
        return True  # Invalid token
