from datetime import datetime, timedelta
from src.common.prisma_cloud.prisma_cloud_auth import PrismaCloudAuth
from src.common.util.constants import PRISMA_TENANT
from src.common.util.requests_utils import HTTPRequest


def container_runtime_audits():
    """
    Get Runtime Container Audit Events
    """
    auth = PrismaCloudAuth()
    token = auth.get_token()
    end = datetime.utcnow()
    start = end - timedelta(minutes=5)
    start = start.strftime("%Y-%m-%dT%H:%M:%SZ")
    end = end.strftime("%Y-%m-%dT%H:%M:%SZ")
    params = {
        "from": start,
        "to": end
    }
    url = PRISMA_TENANT
    endpoint = "audits/runtime/container"

    authentication = {
        "x-redlock-auth": token
    }
    request_connection = HTTPRequest(url, authentication)
    response = request_connection.request(
        method="GET",
        endpoint=endpoint,
        params=params
    )
    return response if response is not None else []


def host_runtime_audits():
    """
    Get Runtime Host Audit Events
    """
    auth = PrismaCloudAuth()
    token = auth.get_token()
    end = datetime.utcnow()
    start = end - timedelta(minutes=5)
    start = start.strftime("%Y-%m-%dT%H:%M:%SZ")
    end = end.strftime("%Y-%m-%dT%H:%M:%SZ")
    params = {
        "from": start,
        "to": end
    }
    url = PRISMA_TENANT
    endpoint = "audits/runtime/host"

    authentication = {
        "x-redlock-auth": token
    }
    request_connection = HTTPRequest(url, authentication)
    response = request_connection.request(
        method="GET",
        endpoint=endpoint,
        params=params
    )
    return response if response is not None else []


def serverless_runtime_audits():
    """
    Get Runtime Serverless Audit Events
    """
    auth = PrismaCloudAuth()
    token = auth.get_token()
    end = datetime.utcnow()
    start = end - timedelta(minutes=5)
    start = start.strftime("%Y-%m-%dT%H:%M:%SZ")
    end = end.strftime("%Y-%m-%dT%H:%M:%SZ")
    params = {
        "from": start,
        "to": end
    }
    url = PRISMA_TENANT
    endpoint = "audits/runtime/serverless"

    authentication = {
        "x-redlock-auth": token
    }
    request_connection = HTTPRequest(url, authentication)
    response = request_connection.request(
        method="GET",
        endpoint=endpoint,
        params=params
    )
    return response if response is not None else []


def waas_container_runtime_audits():
    """
    Get WAAS Container Audit Events
    """
    auth = PrismaCloudAuth()
    token = auth.get_token()
    end = datetime.utcnow()
    start = end - timedelta(minutes=5)
    start = start.strftime("%Y-%m-%dT%H:%M:%SZ")
    end = end.strftime("%Y-%m-%dT%H:%M:%SZ")
    params = {
        "from": start,
        "to": end
    }
    url = PRISMA_TENANT
    endpoint = "audits/firewall/app/container"

    authentication = {
        "x-redlock-auth": token
    }
    request_connection = HTTPRequest(url, authentication)
    response = request_connection.request(
        method="GET",
        endpoint=endpoint,
        params=params
    )
    return response if response is not None else []


def waas_host_runtime_audits():
    """
    Get WAAS Host Audit Events
    """
    auth = PrismaCloudAuth()
    token = auth.get_token()
    end = datetime.utcnow()
    start = end - timedelta(minutes=5)
    start = start.strftime("%Y-%m-%dT%H:%M:%SZ")
    end = end.strftime("%Y-%m-%dT%H:%M:%SZ")
    params = {
        "from": start,
        "to": end
    }
    url = PRISMA_TENANT
    endpoint = "audits/firewall/app/host"

    authentication = {
        "x-redlock-auth": token
    }
    request_connection = HTTPRequest(url, authentication)
    response = request_connection.request(
        method="GET",
        endpoint=endpoint,
        params=params
    )
    return response if response is not None else []


def waas_serverless_runtime_audits():
    """
    Get WAAS Serverless Audit Events
    """
    auth = PrismaCloudAuth()
    token = auth.get_token()
    end = datetime.utcnow()
    start = end - timedelta(minutes=5)
    start = start.strftime("%Y-%m-%dT%H:%M:%SZ")
    end = end.strftime("%Y-%m-%dT%H:%M:%SZ")
    params = {
        "from": start,
        "to": end
    }
    url = PRISMA_TENANT
    endpoint = "audits/firewall/app/serverless"

    authentication = {
        "x-redlock-auth": token
    }
    request_connection = HTTPRequest(url, authentication)
    response = request_connection.request(
        method="GET",
        endpoint=endpoint,
        params=params
    )
    return response if response is not None else []
