from src.common.prisma_cloud.prisma_cloud_auth import PrismaCloudAuth
from src.common.util.constants import PRISMA_API_URL
from src.common.util.requests_utils import HTTPRequest


def alert_rules():
    url = PRISMA_API_URL
    time_unit = "minute"
    time_amount = 5
    endpoint = f"alert?timeType=relative&timeAmount={time_amount}&timeUnit={time_unit}&detailed=true"
    auth = PrismaCloudAuth()
    token = auth.get_token()
    authentication = {
        "x-redlock-auth": token
    }
    request_connection = HTTPRequest(url, authentication)
    response = request_connection.request(
        method="GET",
        endpoint=endpoint
    )
    return response
