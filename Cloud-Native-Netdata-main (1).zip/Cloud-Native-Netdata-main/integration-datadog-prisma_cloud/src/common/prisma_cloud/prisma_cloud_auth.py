import os
from src.common.util.constants import (
    PRISMA_ACCESS_KEY_ID,
    PRISMA_SECRET_ACCESS_KEY,
    PRISMA_TENANT,
    PRISMA_API_URL
)
from src.common.util.jwt_utils import is_jwt_expired
from src.common.util.requests_utils import HTTPRequest


class PrismaCloudAuth:

    def __init__(self) -> None:
        self._PRISMA_ACCESS_KEY_ID = PRISMA_ACCESS_KEY_ID
        self._PRISMA_SECRET_ACCESS_KEY = PRISMA_SECRET_ACCESS_KEY
        self._PRISMA_TENANT = PRISMA_TENANT
        self._PRISMA_API_URL = PRISMA_API_URL
        self.token = ""

    def get_token(self) -> str:
        """
        Gets a Prisma Cloud access token.
        """
        self.token = os.environ.get("PRISMA_CLOUD_ACCESS_TOKEN", "")
        if self.token == "" or is_jwt_expired(self.token):
            payload = {
                "password": self._PRISMA_SECRET_ACCESS_KEY,
                "username": self._PRISMA_ACCESS_KEY_ID,
            }
            request_connection = HTTPRequest(self._PRISMA_API_URL)
            response = request_connection.request(
                method="POST",
                endpoint="login",
                payload=payload,
            )
            if response.get("token"):
                self.token = response["token"]
                os.environ["PRISMA_CLOUD_ACCESS_TOKEN"] = self.token
            else:
                raise Exception("Failed to get Prisma Cloud access token")
        return self.token
