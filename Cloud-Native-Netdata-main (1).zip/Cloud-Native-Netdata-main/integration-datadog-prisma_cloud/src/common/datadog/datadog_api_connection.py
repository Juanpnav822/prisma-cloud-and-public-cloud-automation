from src.common.util.constants import DD_API_URL, DD_API_KEY
from src.common.util.requests_utils import HTTPRequest


def datadog_send_log(payload: str or dict):
    url = DD_API_URL
    endpoint = "v1/input"
    authentication = {
        "DD-API-KEY": DD_API_KEY
    }
    request_connection = HTTPRequest(url, authentication)
    response = request_connection.request(
        method="POST",
        endpoint=endpoint,
        payload=payload
    )
    return response
