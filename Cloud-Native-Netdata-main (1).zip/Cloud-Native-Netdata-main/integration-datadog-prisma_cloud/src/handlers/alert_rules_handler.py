import logging
import json

from src.common.datadog.datadog_api_connection import datadog_send_log
from src.common.prisma_cloud.prisma_cloud_cspm import alert_rules


def alert_rules_handler(event, context):
    # log the event
    logging.info("Event: Send last 5-minute alerts to Datadog")
    logging.info("Requesting alerts from Prisma Cloud")
    prisma_alert_rules = alert_rules()
    total_alerts = len(prisma_alert_rules)
    if total_alerts == 0:
        logging.info("No alerts found in Prisma Cloud")
        return {
            "body": json.dumps({
                "message": "No alerts found in Prisma Cloud",
            }),
        }
    for count, alert in enumerate(prisma_alert_rules):
        payload = {
            "ddsource": "prisma_cloud",
            "message": alert,
            "service": "alert_rules",
        }
        datadog_send_log(payload)
        logging.info(f"{count + 1} / {total_alerts} alerts sent to Datadog")
    logging.info("Alerts sent to Datadog")
    return {
        "body": json.dumps({
            "message": "Alerts sent to Datadog",
        }),
    }
