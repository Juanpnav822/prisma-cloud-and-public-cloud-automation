import logging
import json

from src.common.datadog.datadog_api_connection import datadog_send_log
from src.common.prisma_cloud.prisma_cloud_cwp import (
    serverless_runtime_audits,
)


def serverless_runtime_audits_handler(event, context):
    # log the event
    logging.info("Event: Send last 5-minute serverless runtime audits to Datadog")
    logging.info("Requesting serverless runtime audits from Prisma Cloud")
    serverless_audits = serverless_runtime_audits()
    total_audits = len(serverless_audits)
    if total_audits == 0:
        logging.info("No serverless audits found in Prisma Cloud")
        return {
            "body": json.dumps({
                "message": "No serverless audits found in Prisma Cloud",
            }),
        }
    for count, audit in enumerate(serverless_audits):
        payload = {
            "ddsource": "prisma_cloud",
            "message": audit,
            "service": "serverless_runtime_audits",
        }
        datadog_send_log(payload)
        logging.info(f"{count + 1} / {total_audits} serverless audits sent to Datadog")
    logging.info("Serverless audits sent to Datadog, response")
    return {
        "body": json.dumps({
            "message": "Serverless audits sent to Datadog",
        }),
    }
