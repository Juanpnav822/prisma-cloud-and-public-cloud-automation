import logging
import json
from src.common.datadog.datadog_api_connection import datadog_send_log
from src.common.prisma_cloud.prisma_cloud_cwp import (
    waas_container_runtime_audits,
)


def waas_container_runtime_audits_handler(event, context):
    # log the event
    logging.info("Event: Send last 5-minute waas container runtime audits to Datadog")
    logging.info("Requesting waas container runtime audits from Prisma Cloud")
    waas_container_audits = waas_container_runtime_audits()
    total_audits = len(waas_container_audits)
    if total_audits == 0:
        logging.info("No waas container audits found in Prisma Cloud")
        return {
            "body": json.dumps({
                "message": "No waas container audits found in Prisma Cloud",
            }),
        }
    for count, audit in enumerate(waas_container_audits):
        payload = {
            "ddsource": "prisma_cloud",
            "message": audit,
            "service": "waas_container_runtime_audits",
        }
        datadog_send_log(payload)
        logging.info(f"{count + 1} / {total_audits} waas container audits sent to Datadog")
    logging.info("waas container audits sent to Datadog, response")
    return {
        "body": json.dumps({
            "message": "waas container audits sent to Datadog",
        }),
    }
