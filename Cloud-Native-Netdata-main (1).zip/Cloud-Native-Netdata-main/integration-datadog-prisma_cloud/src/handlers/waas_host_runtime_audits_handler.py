import logging
import json
from src.common.datadog.datadog_api_connection import datadog_send_log
from src.common.prisma_cloud.prisma_cloud_cwp import (
    waas_host_runtime_audits,
)


def waas_host_runtime_audits_handler(event, context):
    # log the event
    logging.info("Event: Send last 5-minute waas host runtime audits to Datadog")
    logging.info("Requesting waas host runtime audits from Prisma Cloud")
    waas_host_audits = waas_host_runtime_audits()
    total_audits = len(waas_host_audits)
    if total_audits == 0:
        logging.info("No waas host audits found in Prisma Cloud")
        return {
            "body": json.dumps({
                "message": "No waas host audits found in Prisma Cloud",
            }),
        }
    for count, audit in enumerate(waas_host_audits):
        payload = {
            "ddsource": "prisma_cloud",
            "message": audit,
            "service": "waas_host_runtime_audits",
        }
        datadog_send_log(payload)
        logging.info(f"{count + 1} / {total_audits} waas host audits sent to Datadog")
    logging.info("waas host audits sent to Datadog, response")
    return {
        "body": json.dumps({
            "message": "waas host audits sent to Datadog",
        }),
    }
