
#* Añadir en requirements.txt los paquete necesarios para el funcionamiento.

import logging, requests, os, json, csv
from datetime import timedelta, datetime, timezone
from azure.storage.blob import BlobServiceClient
import azure.functions as func


#* Para trabajar el proyecto local, las variables de entorno deben estar dentro del archivo local.settings.json, para subir el proyecto a Azure las varaibles deben estar dentro de Application Settings de la Function App

# connection string del storage account que se utilizará
connection_string = os.environ['CONNECTION_STRING']

# Nombre del container en donde se requieren los logs
container_name = "logsprismacloud"

# Base URL del tenant de CWPP de Prisma Cloud
tenant = os.environ['tenant']

# Access Key de autenticación de Prisma Cloud
ACCESS_KEY_ID = os.environ['ACCESS_KEY_ID']
SECRET_ACCESS_KEY = os.environ['SECRET_ACCESS_KEY']

# Enpoints de reportes de interes de Prisma Cloud
access = "audits/access/download"
container = "audits/runtime/container/download"
hosts = "audits/runtime/host/download"
trust = "audits/trust/download"

now = datetime.utcnow()

# Delta de tiempo en minutos de los logs generados en Prisma Cloud
delta_number = 5
delta = now - timedelta(minutes = delta_number)



def getToken(accesskey, secret):
    """
    Obtiene el token de autenticación utilizando la clave de acceso y el secreto proporcionados.

    Args:
        accesskey (str): Clave de acceso para la autenticación.
        secret (str): Secreto para la autenticación.

    Returns:
        str: Token de autenticación.

    Raises:
        Exception: Si la autenticación no es exitosa.
    """

    token = ""
    # Endpoint para la autenticación en el modulo de CWPP
    loginurl = "https://{}/api/v22.06/authenticate".format(tenant)

    # Cuerpo de la petición HTTP del endpoint
    credentials = {"username": accesskey,"password": secret}
    payload = json.dumps(credentials)

    # Headers de la petición HTTP del endpoint
    headers = {
        "Accept": "application/json; charset=UTF-8",
        "Content-Type": "application/json; charset=UTF-8"
    }

    # Realizar la solicitud HTTP POST para la autenticación
    loginresp = requests.request("POST", loginurl, data=payload, headers=headers)

    # Verificar si la autenticación fue exitosa
    if loginresp.status_code == 200:
        loginresp = json.loads(loginresp.text)
        token = loginresp['token']
        print('Autenticado exitoso en ' + loginurl + '...\n')
    else:
        print('Validar credenciales y/o tenant...\n')
        raise Exception("Validar credenciales y/o tenant...")

    return token


def getRuntimeLogs(token, event, r):
    """
    Obtiene los registros de tiempo de ejecución (logs) de un evento específico.

    Args:
        token (str): Token de autenticación.
        event (str): Nombre del evento del cual se obtendrán los logs.
        r (str): Identificador de referencia.

    Returns:
        None

    Raises:
        None
    """

    # Construir la URL para la solicitud GET
    url = "https://{}/api/v1/{}".format(tenant, event)

    # Establecer los parámetros de la consulta
    querystring = {"from": f"{delta.isoformat()}Z", "to": f"{now.isoformat()}Z"}

    # Establecer los encabezados de la solicitud
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    # Realizar la solicitud GET para obtener los logs
    logs = requests.request("GET", url, headers=headers, params=querystring)
    url_content = logs.content

    # Verificar si los logs están vacíos
    if len(url_content) <= 8:
        logging.info('Información vacía.. No hay logs nuevos')
    else:
        # Obtener la fecha actual
        date_now = datetime.now()

        # Formatear la fecha en el formato deseado
        format_date = date_now.strftime("%d_%m_%Y")

        # Subir el archivo blob al almacenamiento
        upload_file_to_blob(url_content, f"{r}_{format_date}.csv")


def upload_file_to_blob(data, file_name):
    """
    Sube datos al almacenamiento blob.

    Args:
        data (str): Datos que se van a subir.
        file_name (str): Nombre del archivo en el almacenamiento blob.

    Returns:
        None

    Raises:
        None
    """

    # Obtener una instancia del cliente del servicio Blob
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)

    # Obtener el cliente del blob especificado
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=file_name)

    # Verificar si el blob ya existe
    if not blob_client.exists():
        # Si el blob no existe, crear uno nuevo en modo Append Blob
        blob_client.create_append_blob()

    # Adjuntar los datos al blob
    blob_client.append_block(data, length=len(data))


def main(mytimer: func.TimerRequest) -> None:
    """
    Función principal que se ejecuta en respuesta a un disparador de temporizador.

    Args:
        mytimer (func.TimerRequest): Información del temporizador.

    Returns:
        None

    Raises:
        None
    """
    utc_timestamp = datetime.utcnow().replace(
        tzinfo=timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    # Obtener el token de autenticación
    token = getToken(ACCESS_KEY_ID, SECRET_ACCESS_KEY)

    # Obtener los registros de tiempo de ejecución para los eventos 'access', 'container', 'hosts' y 'trust'
    getRuntimeLogs(token,access,r='access')
    getRuntimeLogs(token,container,r='container')
    getRuntimeLogs(token,hosts, r='hosts')
    getRuntimeLogs(token,trust, r='trust')

