import requests, json, boto3, os, csv, io, uuid
from botocore.exceptions import ClientError
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication


client_ses = boto3.client('ses')

PRISMA_ACCESS_KEY_ID = os.environ['PRISMA_ACCESS_KEY_ID']
PRIMAS_SECRET_ACCESS_KEY = os.environ['PRIMAS_SECRET_ACCESS_KEY']
TENANT = os.environ['TENANT']
CWPP = os.environ['CWPP']


def loginCSPM():
    url = f"https://{TENANT}/login"
    payload = {
        "password": PRIMAS_SECRET_ACCESS_KEY,
        "username": PRISMA_ACCESS_KEY_ID,
    }
    headers = {"content-type": "application/json; charset=UTF-8"}
    response = requests.request("POST", url, json=payload, headers=headers)
    if response.status_code == 200:
        return (json.loads(response.text))["token"]
    else: 
        raise ValueError(response.text)
    

def loginCWPP():
    url = f"https://{CWPP}/api/v22.06/authenticate"
    payload = {
        "password": PRIMAS_SECRET_ACCESS_KEY,
        "username": PRISMA_ACCESS_KEY_ID,
    }
    headers = {"content-type": "application/json; charset=UTF-8"}
    response = requests.request("POST", url, json=payload, headers=headers)
    if response.status_code == 200:
        return (json.loads(response.text))["token"]
    else: 
        raise ValueError(response.text)


def get_licensing_usage(token):
    url = f"https://{TENANT}/license/api/v2/usage"
    payload = {
        "accountIds": [],
        "limit": 300,
        "cloudTypes": ["aws", "azure", "gcp", "oci", "alibaba_cloud", "others", "repositories"],
        "timeRange": {
            "type": "relative",
            "value": {
                "unit": "hour",
                "amount": 6
            },
        },
        # "timeRange": {
        #     "type": "absolute",
        #     "value": {
        #         "endTime": 1677560399999,
        #         "startTime": 1677517200000
        #     }
        # }
    }
    headers = {
        "content-type": "application/json; charset=UTF-8",
        "x-redlock-auth": token
    }
    
    response = requests.request("POST", url, json=payload, headers=headers)
    if response.status_code == 200:
        return (json.loads(response.content))
    else: 
        raise ValueError(response.text)


def get_licensing_timeseries(token):
    url = f"https://{TENANT}/license/api/v2/time_series"
    payload = {
        "accountIds": [],
        "limit": 300,
        "cloudTypes": ["aws", "azure", "gcp", "oci", "alibaba_cloud", "others"],
        "timeRange": {
            "type": "relative",
            "value": {
                "unit": "month",
                "amount": 3
            },
        }
    }
    headers = {
        "content-type": "application/json; charset=UTF-8",
        "x-redlock-auth": token
    }
    
    response = requests.request("POST", url, json=payload, headers=headers)
    if response.status_code == 200:
        print(response.content)
    else: 
        raise ValueError(response.text)


def get_licensing_info(token):
    url = f"https://{TENANT}/license"

    headers = {
        "content-type": "application/json; charset=UTF-8",
        "x-redlock-auth": token
    }
    
    response = requests.request("GET", url, headers=headers)
    if response.status_code == 200:
        # print(response.content)
        return (json.loads(response.content))
    else: 
        raise ValueError(response.text)


def send_email():
    SENDER = "Licensing Prisma Cloud <cristian.zapata@netdatanetworks.com>"
    CHARSET = "UTF-8"
    BODY_TEXT = ("Amazon SES Test (Python)\r\n"
             "This email was sent with Amazon SES using the "
             "AWS SDK for Python (Boto)."
            )
    SUBJECT = "Amazon SES Test (SDK for Python)"
    BODY_HTML = """<html>
    <head></head>
    <body>
    <h1>Amazon SES Test (SDK for Python)</h1>
    <p>This email was sent with
        <a href='https://aws.amazon.com/ses/'>Amazon SES</a> using the
        <a href='https://aws.amazon.com/sdk-for-python/'>
        AWS SDK for Python (Boto)</a>.</p>
    </body>
    </html>
                """   
    # CONFIGURATION_SET = "ConfigSet"

    try:
        #Provide the contents of the email.
        response = client_ses.send_email(
            Destination={
                'ToAddresses': [
                    "cristian.zapata@netdatanetworks.com",
                ],
            },
            Message={
                'Body': {
                    'Html': {
                        'Charset': CHARSET,
                        'Data': BODY_HTML,
                    },
                    'Text': {
                        'Charset': CHARSET,
                        'Data': BODY_TEXT,
                    },
                },
                'Subject': {
                    'Charset': CHARSET,
                    'Data': SUBJECT,
                },
            },
            Source=SENDER,
            # If you are not using a configuration set, comment or delete the
            # following line
            # ConfigurationSetName=CONFIGURATION_SET,
        )
    # Display an error if something goes wrong.	
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])


def send_attach_email(data, number_credits, avg_usage_credits):
    SENDER = "Licensing Prisma Cloud <cristian.zapata@netdatanetworks.com>"
    RECIPIENT = "cristian.zapata@netdatanetworks.com"
    CHARSET = "UTF-8"
    BODY_TEXT = ("Alerta Consumo de Créditos de Prisma Cloud")
    SUBJECT = "ALERTA! CONSUMO DE CRÉDITOS DE PRISMA CLOUD"
    BODY_HTML = f"""<html>
    <head></head>
    <body>
    <h1>ALERTA! CONSUMO DE CRÉDITOS DE PRISMA CLOUD HA SUPERADO EL LIMITE</h1>
    <p>
        Los créditos consumidos en las últimas 6 horas superan el limite establecido de {number_credits} por un valor de {avg_usage_credits-number_credits}, por lo tanto el consumo promedio en las ultimas horas tiene un valor de {avg_usage_credits}, se adjunta un csv con la información detallada del consumo de creditos por módulos.
    </p>
    </body>
    </html>
                """   
    msg = MIMEMultipart('mixed')
    # Add subject, from and to lines.
    msg['Subject'] = SUBJECT 
    msg['From'] = SENDER 
    msg['To'] = RECIPIENT

    # Create a multipart/alternative child container.
    msg_body = MIMEMultipart('alternative')

    # Encode the text and HTML content and set the character encoding. This step is
    # necessary if you're sending a message with characters outside the ASCII range.
    textpart = MIMEText(BODY_TEXT.encode(CHARSET), 'plain', CHARSET)
    htmlpart = MIMEText(BODY_HTML.encode(CHARSET), 'html', CHARSET)

    # Add the text and HTML parts to the child container.
    msg_body.attach(textpart)
    msg_body.attach(htmlpart)

    # datos = [
    #     {"nombre": "Juan", "edad": 25, "ciudad": "Madrid"},
    #     {"nombre": "María", "edad": 30, "ciudad": "Barcelona"},
    #     {"nombre": "Pedro", "edad": 35, "ciudad": "Valencia"},
    # ]

    # print(datos[0].keys)

    # Crea el buffer de CSV
    buffer_csv = io.StringIO()

    # Define los encabezados de las columnas
    print(list(data[0].keys()))
    encabezados = list(data[0].keys())

    # Crea el escritor de CSV para el buffer
    escritor_csv = csv.DictWriter(buffer_csv, fieldnames=encabezados)

    # Escribe los encabezados en el archivo de CSV
    escritor_csv.writeheader()

    # Escribe los datos del diccionario en el archivo de CSV
    for row in data:
        escritor_csv.writerow(row)

    # Obtén el contenido del buffer de CSV como una cadena
    contenido_csv = buffer_csv.getvalue()

    # Imprime el contenido del buffer de CSV
    print(contenido_csv)

    # Define the attachment part and encode it using MIMEApplication.
    att = MIMEApplication(contenido_csv)

    # Add a header to tell the email client to treat this part as an attachment,
    # and to give the attachment a name.
    att.add_header('Content-Disposition','attachment', filename="report.csv")

    # Attach the multipart/alternative child container to the multipart/mixed
    # parent container.
    msg.attach(msg_body)

    # Add the attachment to the parent container.
    msg.attach(att)
    #print(msg)
    try:
        #Provide the contents of the email.
        response = client_ses.send_raw_email(
            Source=SENDER,
            Destinations=[
                RECIPIENT
            ],
            RawMessage={
                'Data':msg.as_string(),
            },
        )
    # Display an error if something goes wrong.	
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])


def lambda_handler(event, context):
    token = loginCSPM()

    print(f"token {token[0: 20]}")

    licensing_info = get_licensing_info(token)
    licensing_usage = get_licensing_usage(token)
    number_credits = licensing_info["workloads"]
    print(licensing_usage)
    print(licensing_usage["stats"])
    avg_usage_credits = licensing_usage["stats"]["total"]
    
    if(avg_usage_credits >  number_credits):
        # print(f"ALERTA!!! Los créditos consumidos en las últimas 6 horas superan el limite establecido de {number_credits} por un valor de {avg_usage_credits-number_credits}")
        send_attach_email([licensing_usage["stats"]], number_credits, avg_usage_credits)

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
