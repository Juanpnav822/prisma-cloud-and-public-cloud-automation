import boto3
import os
import subprocess
from botocore.exceptions import BotoCoreError, ClientError

def get_temporary_credentials(assume_role_arn, aws_region, aws_access_key, aws_secret_key):
    """
    Obtiene credenciales temporales de AWS STS.
    """
    if not all([assume_role_arn, aws_region, aws_access_key, aws_secret_key]):
        raise ValueError("Faltan parámetros para obtener credenciales temporales.")

    try:
        sts_client = boto3.client(
            'sts',
            region_name=aws_region,
            aws_access_key_id=aws_access_key,
            aws_secret_access_key=aws_secret_key
        )

        assumed_role = sts_client.assume_role(
            RoleArn=assume_role_arn,
            RoleSessionName="temporary-session"
        )

        credentials = assumed_role['Credentials']
        return {
            'accessKeyId': credentials['AccessKeyId'],
            'secretAccessKey': credentials['SecretAccessKey'],
            'sessionToken': credentials['SessionToken']
        }

    except (BotoCoreError, ClientError) as error:
        raise Exception(f"Error al asumir el rol: {error}")

def load_lambda_layer(layer_name, output_file, assume_role_arn, aws_region, aws_access_key, aws_secret_key):
    """
    Carga una versión de capa de Lambda utilizando AWS CLI.
    """
    if not all([layer_name, output_file, assume_role_arn, aws_region, aws_access_key, aws_secret_key]):
        raise ValueError("Faltan argumentos para cargar la capa de Lambda.")

    try:
        # Obtener credenciales temporales
        temp_credentials = get_temporary_credentials(assume_role_arn, aws_region, aws_access_key, aws_secret_key)

        # Establecer credenciales en el entorno
        os.environ['AWS_ACCESS_KEY_ID'] = temp_credentials['accessKeyId']
        os.environ['AWS_SECRET_ACCESS_KEY'] = temp_credentials['secretAccessKey']
        os.environ['AWS_SESSION_TOKEN'] = temp_credentials['sessionToken']

        # Comando CLI para publicar una versión de capa de Lambda
        aws_cli_command = f"aws lambda publish-layer-version --layer-name {layer_name} --zip-file fileb://{output_file} --compatible-runtimes nodejs18.x --compatible-architectures x86_64"

        # Ejecutar el comando CLI
        subprocess.run(aws_cli_command, check=True, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print("La capa de Lambda se ha cargado con éxito.")
    except (BotoCoreError, ClientError, subprocess.CalledProcessError) as error:
        raise Exception(f"Error al cargar la capa de Lambda: {error}")

def get_latest_layer_arn(layer_name, aws_region):
    """
    Obtiene el ARN de la última versión de un layer de AWS Lambda.
    """
    if not layer_name:
        raise ValueError("Nombre del layer no proporcionado.")

    try:
        lambda_client = boto3.client('lambda', region_name=aws_region)
        response = lambda_client.list_layer_versions(
            LayerName=layer_name,
            MaxItems=1
        )
        latest_layer = response['LayerVersions'][0]
        return latest_layer['LayerVersionArn']
    except ClientError as error:
        raise Exception(f"Error al obtener el ARN del layer: {error}")

def add_layer_to_lambda_function(lambda_function_name, layer_arn, aws_region):
    """
    Añade un layer a una función de AWS Lambda.
    """
    if not lambda_function_name or not layer_arn:
        raise ValueError("Nombre de la función Lambda o ARN del layer no proporcionado.")

    try:
        lambda_client = boto3.client('lambda', region_name=aws_region)
        response = lambda_client.update_function_configuration(
            FunctionName=lambda_function_name,
            Layers=[layer_arn]
        )
        return response
    except ClientError as error:
        raise Exception(f"Error al agregar el layer a la función Lambda: {error}")

def get_original_handler(lambda_client, function_name):
    """
    Obtiene el controlador original de una función Lambda.
    """
    if not function_name:
        raise ValueError("Nombre de la función Lambda no proporcionado.")
    
    try:
        response = lambda_client.get_function_configuration(FunctionName=function_name)
        return response['Handler']
    except ClientError as error:
        raise Exception(f"Error al obtener el controlador original: {error}")
    
def update_lambda_configuration(function_name, new_handler, assume_role_arn, aws_region, aws_access_key, aws_secret_key, tw_policy):
    """
    Actualiza la configuración de una función Lambda.
    """
    if not all([function_name, new_handler, assume_role_arn, aws_region, aws_access_key, aws_secret_key, tw_policy]):
        raise ValueError("Faltan argumentos para actualizar la configuración de Lambda.")

    try:
        # Obtener credenciales temporales
        temp_credentials = get_temporary_credentials(assume_role_arn, aws_region, aws_access_key, aws_secret_key)

        # Crear un cliente de Lambda con las credenciales temporales
        lambda_client = boto3.client(
            'lambda', 
            region_name=aws_region,
            aws_access_key_id=temp_credentials['accessKeyId'],
            aws_secret_access_key=temp_credentials['secretAccessKey'],
            aws_session_token=temp_credentials['sessionToken']
        )

        # Obtener el controlador original y TW_POLICY
        original_handler = get_original_handler(lambda_client, function_name)

        if original_handler != "twistlock.handler":
            # Preparar las variables de entorno, incluyendo el controlador original
            env_vars = {
                'Variables': {
                    "ORIGINAL_HANDLER": original_handler,
                    "TW_POLICY": tw_policy,
                    "NEW_HANDLER": new_handler
                }
            }

            # Actualizar la configuración de la función Lambda
            lambda_client.update_function_configuration(
                FunctionName=function_name,
                Environment=env_vars,
                Handler=new_handler  # Establecer el nuevo controlador
            )

        print("Configuración de la función Lambda actualizada con éxito")

    except (BotoCoreError, ClientError) as error:
        raise Exception(f"Error al actualizar la configuración de la función Lambda: {error}")