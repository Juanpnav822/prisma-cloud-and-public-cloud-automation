import time
import prisma_utils
import aws_utils
import config
from botocore.exceptions import ClientError

def main():
    try:
        # Autenticación con Prisma Cloud
        token = prisma_utils.authenticate_with_prisma_cloud(config.PRISMA_ACCESS_KEY, config.PRISMA_SECRET_KEY)

        # Obtención de Defender Layer desde Prisma Cloud
        prisma_utils.get_defender_layer(token, config.RUNTIME, config.PROVIDER, config.OUTPUT_FILE)

        # Obtención de la política TW de Prisma Cloud
        tw_policy = prisma_utils.get_tw_policy(token, config.LAMBDA_FUNCTION_NAME)

        # Carga de la capa de Lambda utilizando las credenciales temporales de STS
        temp_credentials = aws_utils.get_temporary_credentials(config.ASSUME_ROLE_ARN, config.AWS_REGION, config.AWS_ACCESS_KEY, config.AWS_SECRET_KEY)
        aws_utils.load_lambda_layer(config.LAYER_NAME, config.OUTPUT_FILE, config.ASSUME_ROLE_ARN, config.AWS_REGION, config.AWS_ACCESS_KEY, config.AWS_SECRET_KEY)

        # Añadir al layer a la función
        layer_arn = aws_utils.get_latest_layer_arn(config.LAYER_NAME, config.AWS_REGION)
        aws_utils.add_layer_to_lambda_function(config.LAMBDA_FUNCTION_NAME, layer_arn, config.AWS_REGION)

        # Retardo antes de actualizar la configuración de Lambda
        time.sleep(30)  # 30 segundos de retardo

        # Intento de actualizar la configuración de Lambda con manejo de reintentos
        retries = 0
        max_retries = 30
        backoff = 30  # segundos

        while retries < max_retries:
            try:
                aws_utils.update_lambda_configuration(config.LAMBDA_FUNCTION_NAME, config.NEW_HANDLER, config.ASSUME_ROLE_ARN, config.AWS_REGION, config.AWS_ACCESS_KEY, config.AWS_SECRET_KEY, tw_policy)
                break  # Si la actualización tiene éxito, salimos del bucle
            except ClientError as error:
                if error.response['Error']['Code'] == 'ResourceConflictException':
                    print(f"Actualización en progreso. Reintentando en {backoff} segundos...")
                    time.sleep(backoff)
                    retries += 1
                    backoff *= 2  # Incrementar el tiempo de espera
                else:
                    raise  # Otro tipo de error, se relanza la excepción

    except Exception as e:
        print(f"Se produjo un error: {e}")

if __name__ == "__main__":
    main()