
# Prisma Cloud Compliance Standards Report Script

## Overview

This script retrieves compliance standards reports for Azure, AWS, GCP, OCI and Alibaba from Prisma Cloud and exports the data to a CSV file. It leverages Prisma Cloud's API to collect the information.

## Requirements

Python 3.x
Entra ID user
Your user has to have access to the Azure key vault secrets containing the keys for the auth with Prisma Cloud.
Region has to be especified in the script manually in the variale region (line 287).
Installed Python libraries: requests, pandas, azure-cli, azure-keyvault-secrets, azure-identity, concurrent-futures (This is optional since the script installs all these libraries by itself in the first run if is necesary)
## Installation

Clone this repository to your local machine.
Use code with caution. Learn more
## Usage

Edit the compReport.py file and provide your region in the line 287.
Run the script from the command line
Follow the instruction the script gives.
## Output

The script will create CSVs files containing the following information for each requirement of compliance standard:

Standard Name (Name of the file)
name (of the requirement)
Description (of the section or control)
Assigned policies
Failed resources (of the selected accounts)
Passed resources (of the selected account)
Total resources
Severity (Critical, high, medium, low, informational)
Passed Resources
Failed Resources
Total Resources
Section (name)

The script will merge all the csv files in one XLSX file keeping the csv files as well.

## Additional Notes

For detailed error messages, enable logging by setting logging.basicConfig(level=logging.DEBUG) in the script.
Refer to the Prisma Cloud API documentation for more information on available endpoints and data structures.
Consider adding error handling and input validation for robustness.
Include a usage example within the README for clarity.
Provide contact information for support or feedback.
Consider adding a section on contributing to the script for collaboration.
## Contributing

We welcome contributions! Please feel free to submit pull requests or open issues for any improvements or bug fixes.
